# Folien0310 - Folie26 - Lemma

G = (V,E) Adj A
G'= (V,E') Adj A'
D' kürzesten Distanzen in G'

z.Z.: 
* D_ij = D_'ij falls D_ij gerade
  D_ij = 2 D'_ij - 1 falls D_ij ungerade

Wir zeigen *:
G = (V,E)

 * -- * -- * - ... - * -- *
 j  k_1  k_2       k_2l-1 j

 D_ij = 2 l

 in G' gibt es die Kanten (i,k_2), (k_2, k_4) .. (k_2i, k_2i+2) .. (k_2l-2, j)
 aber Weg hat Länge l
 Hätte ich in G' einen Weg der Länge l-1 von i nach j, 
 so müsste es einen Weg der Länge <= 2l-2 in G von i nach j geben. qed.


