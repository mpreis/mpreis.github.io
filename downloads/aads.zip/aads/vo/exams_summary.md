# AADS-Zusammenfassung

__# Prüfungen__ = 5

 - __100%__ Was haben wir alles während der VO besprochen? Überblick?
 - __100%__ Primzahltests erklären (Welche Schritte haben wir in der VO besprochen? Sätze!)
 - __80%__ Segmentschnittproblem erklären (Wie läuft der Algorithmus ab? (mit Skizze)
 - __80%__ Dynamische Programmierung: Matrixkettenmultiplikation Algorithmus erklären
 - __80%__ Fibonacci Heaps erklären (Aufbau, Laufzeiten, Operationen, Warum ist das Array 2 log n?)
 - __40%__ Hashing: Problemstellung und universelles Hashing (grundlegende Idee + Teilbeweis, dass H mit h_ab(x) universelle Klasse ist)
 - __20%__ Treaps erklären (Aufbau, Eigenschaften, Löschen, Rotieren)
 - __20%__ BPWM erklären (Zeugen usw., was wird gemacht und warum) + Beweis Urne skizzieren

## Termin, MO, 11.7.2016 16:00
 - Was haben wir alles während der VO besprochen? Überblick?
 - Segmentschnittproblem erklären (Wie läuft der Algorithmus ab? (mit Skizze)
 - Primzahltests erklären (Welche Schritte haben wir in der VO besprochen? Sätze!)
 - Treaps erklären (Aufbau, Eigenschaften, Löschen, Rotieren)
 - Fibonacci Heaps erklären (Aufbau, Laufzeiten, Operationen)
 - Dynamische Programmierung: Matrixkettenmultiplikation Algorithmus erklären

## Termin, MO, 11.7.2016 16:30
 - Was haben wir alles während der VO besprochen? Überblick?
 - Segmentschnittproblem erklären
 - Primzahltests erklären
 - Fibonacci Heaps erklären
 - Dynamische Programmierung: Matrixkettenmultiplikation Algorithmus erklären

Alles in allem fair, und eher “lockerer”. 

## Termin, DI, 12.7.2016 16:00
 - Was haben wir alles während der VO besprochen? Überblick?
 - Segmentschnittstellenproblem erklären
 - Primzahltests erklären
 - Fibonacci Heaps erklären und Laufzeit
 - Hashing: Problemstellung und universelles Hashing
 - Dynamische Programmierung: Matrixkettenmultiplikation Algorithmus erklären

## Termin, DI, 12.7.2016 17:00
 - Was haben wir alles während der VO besprochen? Überblick?
 - Segmentschnittstellenproblem erklären (Beispiel)
 - Primzahltests erklären (Kleiner Fermat und nicht-triviale Quadratwurzel)
 - Fibonacci Heaps erklären (Warum ist das Array 2 log n?)
 - Dynamische Programmierung: Matrixkettenmultiplikation Algorithmus erklären

## Termin, DI, 12.7.2016 17:30
 - Was haben wir alles während der VO besprochen? Überblick?
 - BPWM erklären (Zeugen usw., was wird gemacht und warum) + Beweis Urne skizzieren
 - Primzahltests erklären
 - Universelles Hashing: grundlegende Idee + Teilbeweis, dass H mit h_ab(x) universelle Klasse ist

