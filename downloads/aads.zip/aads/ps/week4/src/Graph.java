import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

/*************************************************
 * Blatt4 Programmieraufgabe
 * 
 * Dalmir Hasic, 1121497
 * Thomas Huetter, 1120239
 * Mario Preishuber, 1120643
 * 
 ************************************************/
public class Graph implements GraphInterface{
	
	/**
	 * Graph g(v,e)
	 */
	private int[][] adjacencyMatrixOfG;
	
	@Override
	public int getBase() { return 0; }

	@Override
	public void setNumberOfNodes(int numberOfNodes) {
		adjacencyMatrixOfG = new int[numberOfNodes][numberOfNodes];
	}

	@Override
	public void addEdge(int nodeA, int nodeB) {
		adjacencyMatrixOfG[nodeA][nodeB] = 1;
		adjacencyMatrixOfG[nodeB][nodeA] = 1;
	}

	@Override
	public int[][] APSP() {
		
		int[][] d = APD(adjacencyMatrixOfG);
		
		int sMax = 3; 
		int n = d.length;
		
		int[][][] w = new int[sMax][n][n];
		for(int s = 0; s < sMax; s++) {
			
			int[][] d_s = new int[n][n];
			for(int i = 0; i < n; i++)
				for(int j = 0; j < n; j++)
					if( (d[i][j]+1) % sMax == s )
						d_s[i][j] = 1;
					
			w[s] = BPWM(adjacencyMatrixOfG, d_s);
		}
		
		int[][] s = new int[n][n];
		for(int i = 0; i < n; i++)
			for(int j = 0; j < n; j++)
				s[i][j] = w[d[i][j]%sMax][i][j];
		
		return s;
	}
	
	/**
	 * Computes the boolean product witness matrix (BPWM) <code>w</code> of the two given
	 * matrixes <code>a</code> and <code>b</code>.
	 * 
	 * @param a adjacency matrix of size <code>n*n</code>
	 * @param b matrix of size <code>n*n</code>
	 * @return The BPWM <code>w</code> for <code>p = a * b</code>.
	 */
	private int[][] BPWM(int[][] a, int[][] b) {
		
		int n = a.length;
		
		/** <code>w_ij < 0 <=> witness of p_ij has to be found.</code> */
		int[][] w = matrixMultiply(-1, matrixMultiply(a, b));
		
		/** try every <code>r = 2^t</code> from <code>1<code> to <code>n</code>. */
		for(double t = 0; t < Math.floor(Math.log(n)); t++) {
			int r = (int)Math.pow(2, t);
			
			for(double k = 0; k < Math.ceil(3.77 * Math.log(n)); k++) {
				
				/** <code>z = a^r*b^r */
				int[][] z = computeBPWMMatrixZ(r, a, b);
				
				/** test if we found a witness for <code>p_ij</code> */
				for(int i = 0; i < n; i++)
					for(int j = 0; j < n; j++) {
						/** <code>z_ij</code> is witness for <code>p_ij</code>. */
						if(w[i][j] < 0 && a[i][z[i][j]] == 1 && b[z[i][j]][j] == 1)
							w[i][j] = z[i][j];
					}
			}
		}
		
		/** for all remaining pairs (<code> w_ij less than 0 </code>) use the 
		 * trivial algorithm to compute a witness. */
		for(int i = 0; i < n; i++)
			for(int j = 0; j < n; j++)
				if(w[i][j] < 0)
					for(int k = 0; k < n; k++)
						/** <code>k</code> is witness for <code>p_ij</code>. */
						if(a[i][k] == 1 && b[k][j] == 1)
							w[i][j] = k;

		return w;
	}
	
	/**
	 * Helper: computes <code>z = a^r * b^r</code>.
	 * 
	 * @param r number of columns/rows which should be kept.
	 * @param a matrix of size <code>n*n</code>
	 * @param b matrix of size <code>n*n</code>
	 * @return <code>z = a^r * b^r</code>
	 */
	private int[][] computeBPWMMatrixZ(int r, int[][] a, int[][] b) {
		
		int n = a.length;
		Random random = new Random();
		
		Set<Integer> gr = new HashSet<Integer>();
		while(gr.size() < r)
			gr.add(random.nextInt(n));
		
		int[][] ar = new int [n][n];
		int[][] br = new int [n][n];
		
		Iterator<Integer> iterGr = gr.iterator();
		while(iterGr.hasNext()) {
			int tmpR = iterGr.next();
			for(int i = 0; i < n; i++) {
				ar[i][tmpR] = a[i][tmpR];
				br[tmpR][i] = b[tmpR][i];
			}
		}
		
		return matrixMultiply(ar, br);
	}
	
	/**
	 * Solve the all pairs distance (APD) problem.
	 * 
	 * @param a adjacency matrix of a graph <code>g</code>.
	 * @return a matrix <code>d[i][j]</code> with the distance from 
	 * 			node <code>i</code> to node <code>j</code>.
	 */
	private int[][] APD(int[][] a) {
		/** 
		 * compute for all node-pairs <code>(i,j)</code> the distance <code>d_ij</code>
		 * in the undirected graph <code>g</code> represented by the parameter <code>a</code>.<br>
		 * (<code>Z = A^2</code>)
		 */
		int[][] z = matrixMultiply(a, a);
		int n = a.length;
		 
		/**
		 * <code>ap_ij = 1</code> <=> there exists a path of length 1 or 2 
		 * from <code>i</code> to <code>j</code>.
		 * compute <code>ap</code>.
		 */
		int[][] ap = new int[n][n];
		for(int i = 0; i < n; i++)
			for(int j = 0; j < n; j++)
				ap[i][j] = (i != j && (a[i][j] == 1 || z[i][j] > 0))
					? 1 : 0;
		
		/**
		 * <code>if ap_ij = 1 forall i!=j then return d = 2*ap - a</code> //end of recursion
		 */
		boolean stopRecursion = true;
		for(int i = 0; i < n && stopRecursion; i++)
			for(int j = 0; j < n && stopRecursion; j++)
				if(i != j && ap[i][j] != 1)
					stopRecursion = false;
		
		if(stopRecursion) 
			return matrixSubtract(matrixMultiply(2, ap), a);	
		
		/**
		 * else continue recursion.
		 */
		int[][] dp = APD(ap);
		
		/**
		 * compute: <code>s = a . dp</code>
		 * with 
		 * 		<code>s_ij = sum_{k in Gamma(i)}(dp_kj)</code><br>
		 * 		<code>Gamma(i)</code> represents all neighbors of <code>i</code><br>
		 */
		
		int[][] s = matrixMultiply(a, dp);
		
		/**
		 * compute: <code>d</code>
		 * with
		 * 		(1) <code>d_ij = 2*dp_ij   if s_ij >= dp_ij * z_ii</code>
		 * 		(2) <code>d_ij = 2*dp_ij-1 if s_ij <  dp_ij * z_ii</code>
		 */
		int[][] d = new int[n][n];
		for(int i = 0; i < n; i++)
			for(int j = 0; j < n; j++)
				d[i][j] = (s[i][j] >= (dp[i][j] * z[i][i]))
					? 2 * dp[i][j] 		/** (1) */
					: 2 * dp[i][j] - 1;	/** (2) */					
		return d;
	}
	
	/**
	 * Multiples the given matrix <code>x</code> with the given constant <code>y</code>.
	 * 
	 * @param x <code>n*m</code> matrix
	 * @param c constant
	 * @return <code>c*x</code>
	 */
	private int[][] matrixMultiply (int c, int[][] x) {
		
		int[][] z = new int[x.length][x[0].length];
		for(int i = 0; i < x.length; i++)
			for(int j = 0; j < x[0].length; j++)
				z[i][j] = x[i][j] * c;
		
		return z;
				
	}

	/**
	 * Multiplies the given matrixes <code>x</code> and <code>y</code>.
	 * 
	 * @param x matrix of size <code>n*m</code>
	 * @param y matrix of size <code>n*m</code>
	 * @return  <code>x * y</code>
	 */
	private int[][] matrixMultiply (int[][] x, int[][] y) {
		
		int n = x.length;
		int m = x[0].length;
		int[][] z = new int[n][m];
		
		for(int i = 0; i < n; i++)
			for(int j = 0; j < m; j++)				
				for(int k = 0; k < m; k++)
					z[i][j] += x[i][k] * y[k][j];
				
		matrixSubtract(x, y);
		return z;
	}
	
	/**
	 * Subtracts from the given matrix <code>x</code> matrix <code>y</code>.
	 * 
	 * @param x matrix of size <code>n*m</code>
	 * @param y matrix of size <code>n*m</code>
	 * @return  <code>x - y</code>
	 */
	private int[][] matrixSubtract(int[][] x, int[][] y) {
		
		int n = x.length;
		int m = x[0].length;
		int[][] z = new int[n][m];
		
		for(int i = 0; i < n; i++)
			for(int j = 0; j < m; j++)
				z[i][j] = x[i][j] - y[i][j];
		
		return z;
	}	
}
