/*************************************************
 * Blatt4 Programmieraufgabe
 * 
 * Dalmir Hasic, 1121497
 * Thomas Huetter, 1120239
 * Mario Preishuber, 1120643
 * 
 ************************************************/

/**
 * a simple interface to specify the input to the APSP problem
 */
public interface GraphInterface {

	/**
	 * initialize the graph with the given number of nodes
	 * 
	 * @param numberOfNodes
	 *            the number of nodes
	 */
	public void setNumberOfNodes(int numberOfNodes);

	/**
	 * add an undirected edge to the graph
	 * 
	 * @param nodeA
	 *            one node incident at the edge
	 * @param nodeB
	 *            the other node incident at the edge
	 */
	public void addEdge(int nodeA, int nodeB);

	/**
	 * solve the APSP problem.
	 * 
	 * @return a matrix A[i,j] with the next hop on the shortest path from node
	 *         i to node j
	 */
	public int[][] APSP();


	/**
	 * get the base index for the node IDs
	 *
	 * @return either 0 or 1, the index of the first node.
	 */
	public int getBase();

}
