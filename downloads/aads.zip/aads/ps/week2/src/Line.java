/*************************************************
 * Blatt2
 * 
 * Dalmir Hasic, 1121497
 * Thomas Huetter, 1120239
 * Mario Preishuber, 1120643
 * 
 ************************************************/

public class Line extends Segment {

	private Double yt;
	
	public Line(Double x, Double yb, Double yt) {
		super(x, yb);
		this.setYt(yt);
	}

	public Double getYb() { return getY(); }
	public void setYb(Double yb) { setY(yb); }
	public Double getYt() { return yt; }
	public void setYt(Double yt) { this.yt = yt; }
	
	@Override
	public int compareTo(Segment o) {
		return getY().compareTo(o.getY());
	}
}
