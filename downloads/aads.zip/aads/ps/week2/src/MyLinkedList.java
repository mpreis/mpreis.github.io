/*************************************************
 * Blatt2
 * 
 * Dalmir Hasic, 1121497
 * Thomas Huetter, 1120239
 * Mario Preishuber, 1120643
 * 
 ************************************************/

import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;


@SuppressWarnings("rawtypes")
public class MyLinkedList<T extends Comparable> extends LinkedList<T> {
	
	private static final long serialVersionUID = 1L;
	
	public void insert(T item) { add(item); }
	public boolean delete(T item) { return remove(item); }
	public T search(T item) { return (T) super.get(super.indexOf(item)); }
	
	@SuppressWarnings("unchecked")
	public void merge(MyLinkedList<T> other) {
		MyLinkedList<T> l3 = new MyLinkedList<T>();
		
		while(!this.isEmpty() || !other.isEmpty()) {
			T thisVal = this.peek();
			T otherVal = other.peek();
			
			if(otherVal == null && thisVal != null) { l3.insert(thisVal); this.removeFirst(); }
			else if(thisVal == null && otherVal != null) { l3.insert(otherVal); other.removeFirst(); }
			else if (thisVal.compareTo(otherVal) < 0) { l3.insert(thisVal); this.removeFirst(); }
			else { l3.insert(otherVal); other.removeFirst(); }
		}
		
		while(!l3.isEmpty())
			this.insert(l3.removeFirst());
	}
	
	@SuppressWarnings("unchecked")
	public void sort(Comparator c) {
	    MyLinkedList<T> tmp = new MyLinkedList<T>();
	    tmp.addAll(this);
	    this.clear();

	    for(int i = 0; i < tmp.size(); i++) {
	    	boolean b = false;

	        for(int j = 0; j < this.size(); j++) {
	            if(c.compare(tmp.get(i), this.get(j)) < 0) {
	                this.add(j, tmp.get(i));
	                b = true;
	                break;
	            }
	        }
	        if(!b) this.addLast(tmp.get(i));
	    }
	}
	
	/**
	 * Prints the list in one line.
	 */
	public void print() {
		Iterator<T> iter = this.iterator();
		while(iter.hasNext()) System.out.print(iter.next() + " ");
		System.out.println();
	}
}
