/*************************************************
 * Blatt2
 * 
 * Dalmir Hasic, 1121497
 * Thomas Huetter, 1120239
 * Mario Preishuber, 1120643
 * 
 ************************************************/

public class Point extends Segment  {

	private Point p;	// other endpoint of horizontal line
	private boolean isLeft;

	public Point(Double x, Double y, Point p, boolean isLeft) {
		super(x, y);
		this.p = p;
		this.isLeft = isLeft;
	}

	public Point(Double x, Double y, boolean isLeft) {
		super(x, y);
		this.p = null;
		this.isLeft = isLeft;
	}
	
	public void setPoint(Point p) { this.p = p; }
	public Point getP() { return p; }
	public boolean isLeft() { return isLeft; }
	public void setLeft(boolean isLeft) { this.isLeft = isLeft; }

	@Override
	public int compareTo(Segment o) {
		return this.getY().compareTo(o.getY());
	}
}
