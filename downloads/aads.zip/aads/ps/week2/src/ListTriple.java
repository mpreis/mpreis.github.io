/*************************************************
 * Blatt2
 * 
 * Dalmir Hasic, 1121497
 * Thomas Huetter, 1120239
 * Mario Preishuber, 1120643
 * 
 ************************************************/

public class ListTriple {
	MyLinkedList<Point> leftEndpoints = new MyLinkedList<Point>();
	MyLinkedList<Point> rightEndpoints = new MyLinkedList<Point>();
	MyLinkedList<Line> verticalLines = new MyLinkedList<Line>();
	
	public ListTriple(MyLinkedList<Point> le, MyLinkedList<Point> re, MyLinkedList<Line> vl) {
		leftEndpoints = le;
		rightEndpoints = re;
		verticalLines = vl;
	}
}
