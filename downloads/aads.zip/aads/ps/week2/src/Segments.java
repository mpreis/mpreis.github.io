/*************************************************
 * Blatt2
 * 
 * Dalmir Hasic, 1121497
 * Thomas Huetter, 1120239
 * Mario Preishuber, 1120643
 * 
 ************************************************/
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Segments {

	static MyLinkedList<Segment> S = new MyLinkedList<Segment>();
	
	public static void main(String args[]) {   
		// read user input.
		Scanner input = new Scanner(System.in);
		String line;
		while(input.hasNextLine()) {
			line = input.nextLine();
			getSegmentFromLine(line);
		}		
		
		try {
			S.sort(new Comparator<Segment>() {
			    @Override
			    public int compare(Segment seg1, Segment seg2) {
			        return  (seg1.getX().compareTo(seg2.getX()));
			    }
			});
			reportCuts(S);
			
			S = new MyLinkedList<Segment>();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		input.close();
	}
	
	public static ListTriple reportCuts(List<Segment> s) throws Exception {
		if(s.size() == 1) {
			Segment seg = s.get(0);
			if(seg == null) 
				throw new Exception("Invalid Segment: Segment is null");
			if(seg instanceof Point) {
				MyLinkedList<Point> tl = new MyLinkedList<Point>();
				tl.insert((Point) seg);
				if(((Point) seg).isLeft()) 
					return new ListTriple(tl, new MyLinkedList<Point>(), new MyLinkedList<Line>());
				else 
					return new ListTriple(new MyLinkedList<Point>(), tl, new MyLinkedList<Line>());
			}
			else {
				MyLinkedList<Line> tl = new MyLinkedList<Line>();
				tl.insert((Line) seg);
				return new ListTriple(new MyLinkedList<Point>(), new MyLinkedList<Point>(), tl);
			}			
		} else {
			List<Segment> s1;
			List<Segment> s2;
			s1 = s.subList(0, (s.size()/2));
			s2 = s.subList((s.size()/2), s.size());
			
			ListTriple lts1 = reportCuts(s1);
			ListTriple lts2 = reportCuts(s2);

            MyLinkedList<Point> removeFromLeft = new MyLinkedList<Point>();
            MyLinkedList<Point> removeFromRight = new MyLinkedList<Point>();
            
            for(Point r2: lts2.rightEndpoints)
            	removeFromLeft.insert(r2.getP());
            
            for(Point l1: lts1.leftEndpoints)
            	removeFromRight.insert(l1.getP());
            
            lts1.leftEndpoints.removeAll(removeFromLeft);
            lts2.rightEndpoints.removeAll(removeFromRight);
			
			int hStart = 0;
			for(Line v: lts2.verticalLines) 
				for(int i = hStart; i < lts1.leftEndpoints.size(); i++) 
					if(v.getYb().compareTo(lts1.leftEndpoints.get(i).getY()) <= 0)
						if(v.getYt().compareTo(lts1.leftEndpoints.get(i).getY()) >= 0)
							System.out.println(v.getX() + " " + lts1.leftEndpoints.get(i).getY());
						else
							break;
					else
						hStart = i;

			int hStart2 = 0;
			for(Line v: lts1.verticalLines) 
				for(int i = hStart2; i < lts2.rightEndpoints.size(); i++) 
					if(v.getYb().compareTo(lts2.rightEndpoints.get(i).getY()) <= 0)
						if(v.getYt().compareTo(lts2.rightEndpoints.get(i).getY()) >=0)
							System.out.println(v.getX() + " " + lts2.rightEndpoints.get(i).getY());
						else
							break;
					else
						hStart2 = i;

			MyLinkedList<Point> le = new MyLinkedList<Point>();
			le.addAll(lts1.leftEndpoints);
			le.merge(lts2.leftEndpoints);

			MyLinkedList<Point> re = new MyLinkedList<Point>();
			re.addAll(lts2.rightEndpoints);
			re.merge(lts1.rightEndpoints);
			
			MyLinkedList<Line> vl = lts1.verticalLines;
			vl.merge(lts2.verticalLines);
			
			return new ListTriple(le, re, vl);
		}
	}
	
	
	/**
	 * Takes a line and returns a Segment.
	 * @param inputLine
	 * @return
	 */	
	public static void getSegmentFromLine(String line) {
        Point lp,rp;
		String[] xyValuesString = line.split(" ");
		double[] xyValuesDouble = new double[xyValuesString.length];
		for(int i = 0; i < xyValuesDouble.length; i++) 
			xyValuesDouble[i] = Double.parseDouble(xyValuesString[i]);
		
		if(xyValuesDouble[0] == xyValuesDouble[2]) { 
	        if(xyValuesDouble[1] < xyValuesDouble[3])
	            S.add(new Line(xyValuesDouble[0], xyValuesDouble[1], xyValuesDouble[3]));
	        else
	            S.add(new Line(xyValuesDouble[0], xyValuesDouble[3], xyValuesDouble[1]));
	    } else {
            if(xyValuesDouble[0] < xyValuesDouble[2]) {
                lp = new Point(xyValuesDouble[0], xyValuesDouble[1], true);
                rp = new Point(xyValuesDouble[2], xyValuesDouble[3], lp, false);
            } else {
                lp = new Point(xyValuesDouble[2], xyValuesDouble[3], true);
                rp = new Point(xyValuesDouble[0], xyValuesDouble[1], lp, false);
            }
            lp.setPoint(rp);
                        
			S.add(lp);
			S.add(rp);
		}
	}
}
