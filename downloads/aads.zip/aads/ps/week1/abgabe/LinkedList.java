/*************************************************
 * Blatt1
 * 
 * Dalmir Hasic, 1121497
 * Thomas Huetter, 1120239
 * Mario Preishuber, 1120643
 * 
 ************************************************/
import java.util.Iterator;

public class LinkedList<T extends Comparable<T>> implements Iterable<T>{

	private Node head;
	private Node tail;
	
	public LinkedList() { head = tail = null; }
	
	/**
	 * Insert item into list.
	 * @param item
	 */
	public void insert(T item) {
		if(this.isEmpty()) {
			head = new Node(item); tail = head;}
		else {
			tail.next = new Node(item); tail = tail.next;}
	}
	
	/**
	 * Delete item from list.
	 * @param item
	 * @return
	 */
	public boolean delete(T item) {
		Node preNode = null;
		Node curNode = head;
		do {
			if(curNode.value.equals(item)) {
				if(preNode == null) head = curNode.next; 	// remove head
				else {
					preNode.next = curNode.next;			// remove inner node
					if(curNode == tail) tail = preNode; }	// remove tail
				return true;
			}	
			preNode = curNode;
			curNode = curNode.next;
			
		} while (curNode != null);
		return false;
	}
	
	/**
	 * Search for item in list.
	 * @param item
	 * @return
	 */
	public T search(T item) {
		Node curNode = head;
		while (curNode != null)
			if(curNode.value.equals(item))
				return curNode.value;
		return null;
	}
	
	/**
	 * Get value of list head.
	 * @return
	 */
	public T peek() { return (this.isEmpty()) ? null : head.value; } 
	
	/**
	 * Check if list is empty.
	 * @return
	 */
	public boolean isEmpty() { return head == null; }
	
	/**
	 * Get list iterator.
	 */
	@Override public Iterator<T> iterator() { return new LLIterator(); }
	
	/**
	 * Print list.
	 */
	public void print() {
		Node tmp = head;
		while (tmp != null) { System.out.print(tmp.value + " "); tmp = tmp.next; }
		System.out.println();
	}
	
	
	/**
	 * Helper: Represents a single node of the list. 
	 */
	private class Node {
		T value;
		Node next;
		Node() { value = null; next = null; }
		Node(T value) { this(); this.value = value; }
	}
	
	/**
	 * Implements the iterator of the list.
	 */
	private class LLIterator implements Iterator<T> {
		private Node iter;
		public LLIterator() { iter = head; }
		@Override public boolean hasNext() { return iter != null; }
		@Override public void remove() { throw new UnsupportedOperationException(); }
		@Override public T next() {
			if(iter == null) return null;
			T val = iter.value;
			iter = iter.next;
			return val;
		}
	}
}
