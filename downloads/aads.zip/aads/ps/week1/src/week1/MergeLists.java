/*************************************************
 * Blatt1
 * 
 * Dalmir Hasic, 1121497
 * Thomas Huetter, 1120239
 * Mario Preishuber, 1120643
 * 
 ************************************************/
package week1;

import java.util.Iterator;
import java.util.Scanner;

public class MergeLists {

	/**
	 * Main program for testing the merge function.
	 * Expects two lists of integers as input (separated by white space).
	 * @param args
	 */
	public static void main(String args[]) {   
		// read user input.
		Scanner input = new Scanner(System.in);
		String inputLine1 = input.nextLine();
		String inputLine2 = input.nextLine();
		input.close();

		// prepare lists.
		LinkedList<Integer> l1 = prepareList(inputLine1);
		LinkedList<Integer> l2 = prepareList(inputLine2);
		LinkedList<Integer> l3 = merge(l1, l2);
		l3.print();
	}
	
	/**
	 * Merges two lists into new list.
	 * @param l1
	 * @param l2
	 * @return
	 */
	private static LinkedList<Integer> merge(LinkedList<Integer> l1, LinkedList<Integer> l2) {
		LinkedList<Integer> l3 = new LinkedList<Integer>();
		
		Iterator<Integer> l1Iter = l1.iterator();
		Iterator<Integer> l2Iter = l2.iterator();
		
		Integer l1Val = l1Iter.next();
		Integer l2Val = l2Iter.next();
		
		while(l1Val != null || l2Val != null) {
			if(l2Val == null && l1Val != null) 		{ l3.insert(l1Val); l1Val = l1Iter.next(); }
			else if(l1Val == null && l2Val != null) { l3.insert(l2Val); l2Val = l2Iter.next(); }
			else if (l1Val < l2Val) 				{ l3.insert(l1Val); l1Val = l1Iter.next(); }
			else									{ l3.insert(l2Val); l2Val = l2Iter.next(); }
		}
		
		return l3;
	}
	
	/**
	 * Convert input string into a list of integers.
	 * @param inputLine
	 * @return
	 */
	private static LinkedList<Integer> prepareList(String inputLine) {
		LinkedList<Integer> l = new LinkedList<Integer>();
		for(String item : inputLine.split(" ", inputLine.length()) )
			if(item.length() > 0)
				l.insert(Integer.parseInt(item));
		return l;
	}
}
