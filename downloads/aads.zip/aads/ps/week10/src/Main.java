import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Random;

public class Main {
	
	public static void main(String [] args) throws Exception {
		int minOps = 1000;
		int maxOps = minOps * 100;
		int reps = 10;
		experiment(reps, minOps, maxOps);
	}
	
	public static void experiment(int reps, int minOps, int maxOps) throws Exception {
		int nrOps = getNrOps(minOps, maxOps);
		Map<Integer, HeapEntryNode<Integer>> entries = getEntries(nrOps);
		List<Benchmark<HeapEntryNode<Integer>>> benchmarks = getBenchmarks(minOps, maxOps, nrOps, entries);
		
		Map<String, List<Long>> samplesPQ = new HashMap<String, List<Long>>();
		Map<String, List<Long>> samplesFH = new HashMap<String, List<Long>>();
		List<Long> benchSamples;
		
		Iterator<Benchmark<HeapEntryNode<Integer>>> iter = benchmarks.iterator();
		while(iter.hasNext()) {
			Benchmark<HeapEntryNode<Integer>> b = iter.next();	
			
			benchSamples = new ArrayList<Long>();
			for(int i = 0; i < reps; i++) {
				b.setQueue(new FibonacciHeap<HeapEntryNode<Integer>>());
				benchSamples.add(b.run());
			}
			samplesFH.put(b.getName(), benchSamples);
			
			benchSamples = new ArrayList<Long>();
			for(int i = 0; i < reps; i++) {
				b.setQueue(new PriorityQueue<HeapEntryNode<Integer>>());
				benchSamples.add(b.run());
			}
			samplesPQ.put(b.getName(), benchSamples);
		}
		
		printResult(samplesFH, "FibonacciHeap");
		printResult(samplesPQ, "PriorityQueue");
	}

	private static int getNrOps(int minOps, int maxOps) {
		Random rand = new Random();
		return rand.nextInt((int)(maxOps - minOps) + 1) + minOps;
	}
	
	private static Map<Integer, HeapEntryNode<Integer>> getEntries(int nrOps) {
		Map<Integer, HeapEntryNode<Integer>> entries = new HashMap<Integer, HeapEntryNode<Integer>>();
		Random rand = new Random();
		for(int i = 0;i < nrOps; i++)
			entries.put(i, new HeapEntryNode<Integer>(rand.nextDouble(), rand.nextInt()));
		
		return entries;
	}
	
	private static List<Benchmark<HeapEntryNode<Integer>>> getBenchmarks(int minOps, int maxOps, int nrOps, 
			Map<Integer, HeapEntryNode<Integer>> entries) throws Exception {
		List<Benchmark<HeapEntryNode<Integer>>> benchmarks = new ArrayList<>();
		
		benchmarks.add(new SequentialAlternatingBenchmark<HeapEntryNode<Integer>>
				("SeqAlt_0           ", nrOps, 0, entries));
		benchmarks.add(new SequentialAlternatingBenchmark<HeapEntryNode<Integer>>
				("SeqAlt_NrOpsHalf   ", nrOps, nrOps/2, entries));
		benchmarks.add(new SequentialAlternatingBenchmark<HeapEntryNode<Integer>>
				("SeqAlt_MinOps      ", nrOps, minOps, entries));
		benchmarks.add(new SequentialAlternatingBenchmark<HeapEntryNode<Integer>>
				("SeqAlt_NrOps-1     ", nrOps, nrOps-1, entries));
		benchmarks.add(new OfferPollBenchmark<HeapEntryNode<Integer>>
				("OfferPoll_NrOpsHalf", nrOps, nrOps/2, entries ));
		benchmarks.add(new OfferPollBenchmark<HeapEntryNode<Integer>>
				("OfferPoll_NrOps2/3 ", nrOps, (2*nrOps)/3, entries));
		benchmarks.add(new OfferPollBenchmark<HeapEntryNode<Integer>>
				("OfferPoll_NrOps1/3 ", nrOps, nrOps/3, entries));
		benchmarks.add(new OfferPollBenchmark<HeapEntryNode<Integer>>
				("OfferPoll_NrOps    ", nrOps, nrOps, entries));
		
		return benchmarks;
	}
	
	
	private static double getAvg(List<Long> samples) {
		Double sum = 0.0;
		for(Long sample : samples) sum += (double)sample;
		return sum / samples.size();
	}
	

	private static double getSSD(double avg, List<Long> samples) {
		double ss = 0.0;
		for(Long sample : samples)
			ss += Math.pow(((double)sample - avg), 2);
		return Math.sqrt( (1.0/(samples.size()-1)) * ss);
	}
	
	private static void printResult(Map<String, List<Long>> samples, String title) {
		System.out.println();
		System.out.println("/// Result " + title + " ///");
		DecimalFormat df = new DecimalFormat("0.000"); 
		for(String bench: samples.keySet()) {
			double avg = getAvg(samples.get(bench));
			double ssd = getSSD(avg, samples.get(bench));
			System.out.println("name:" + bench + "\t avg:" + df.format(avg) + "ms,\t ssd:" + df.format(ssd));
		}
	}
		
}
