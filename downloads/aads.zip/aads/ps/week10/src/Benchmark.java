import java.util.AbstractQueue;
import java.util.Map;

public abstract class Benchmark<E extends HeapEntry> {
	protected int nrOps;
	protected Map<Integer, E> entries;
	protected AbstractQueue<E> queue;
	
	protected final String benchName;
	
	public Benchmark(String benchName, int nrOps, Map<Integer, E> entries) {
		this.nrOps = nrOps;
		this.entries = entries;
		this.benchName = benchName;
	}
	public Benchmark(String benchName, int nrOps, Map<Integer, E> entries, AbstractQueue<E> queue) {
		this(benchName, nrOps, entries);
		this.queue = queue;
	}
	
	public void setQueue(AbstractQueue<E> queue) {
		this.queue = null;
		this.queue = queue;
	}
	
	
	public abstract long run();
	public abstract String getSettings();
	
	public void printResult(long execTime) {
		String benchmarksSpecificSettings = this.getSettings();
		System.out.println("name:" + benchName + ", nrOps:" + nrOps + ", " + benchmarksSpecificSettings + ", execTime:" + execTime + "ms");
	}
	
	public String getName() { return benchName; }
}
