import java.util.AbstractQueue;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class FibonacciHeap<E extends HeapEntry> extends AbstractQueue<E> {

	private int n;
	private Node min;
	
	public FibonacciHeap() {
		n = 0;
		min = null;
	}
	
	@Override public boolean offer(E e) { return (insert(e) != null); }
	@Override public E poll() { return deleteMin(); }
	@Override public E peek() { return min.entry; }
	@Override public Iterator<E> iterator() { return null; }
	@Override public int size() { return n; }
	
	public void delete(E e) throws Exception {
		decreaseKey(e, Double.NEGATIVE_INFINITY);
		deleteMin();
	}
	
	private Node insert(E e) {
		Node x = new Node(e);
		if(min == null) {
			rootlistCreateAndAdd(x);
		} else {
			rootlistAdd(x);
			if(x.entry.getKey() < min.entry.getKey())
				min = x;
		}
		n += 1;
		return x;
	}
	
	private E deleteMin() {
		Node tmpMin = min;
		if (tmpMin != null) {
			Node tmpChild = tmpMin.child;
			for(int i = 0; i < tmpMin.degree; i++) {
				Node tmpChildRight = tmpChild.right;
				rootlistAdd(tmpChild);
				tmpChild.parent = null;
				tmpChild = tmpChildRight;
			}
			rootlistRemove(tmpMin);
			if(tmpMin == tmpMin.right)
				min = null;
			else {
				min = tmpMin.right;
				consolidate();
			}
			n -= 1;
			return tmpMin.entry;
		}
		return null;
	}
	
	private void consolidate() {
		Map<Integer, Node> A = new HashMap<Integer, Node>();
		Node x = min;
		do {
			int d = x.degree;
			while(A.containsKey(d) && A.get(d) != x) {
				Node y = A.get(d);
				if (x.entry.getKey() > y.entry.getKey()) {
					Node tmp = x;
					x = y;
					y = tmp;
				} 
				link(y, x);
				A.remove(d);
				d += 1;
			}
			A.put(d, x);
			x = x.right;
		} while(!x.equals(min));
		
		for(Node ai: A.values())
			if(ai.entry.getKey() < min.entry.getKey())
				min = ai;
	}
	
	private void link(Node y, Node x) {
		rootlistRemove(y);

		if(y.equals(min))
			min = x;
		
		if(x.child != null) {
			y.left = x.child.left;
			x.child.left.right = y;
			x.child.left = y;
			y.right = x.child;
		} else {
			y.right = y;
			y.left = y;
		}
		
		y.parent = x;
		x.child = y;
				
		x.degree += 1;
		y.marked = false;
	}
	
	private void decreaseKey(E e, Double k) throws Exception {
		Node x = new Node(e);
		if(k > x.entry.getKey())
			throw new Exception("New key is greater than current key.");
		
		x.entry.setKey(k);
		Node y = x.parent;
		
		if(y != null && x.entry.getKey() < y.entry.getKey()) {
			cut(x, y);
			cascadingCut(y);
		}
		
		if(x.entry.getKey() < min.entry.getKey()) min = x;
	}
	
	private void cut(Node x, Node y) {
		x.left.right = x.right;
		x.right.left = x.left;
		if(y.child == x)
			y.child = x.right;

		x.parent = null;
		
		y.degree -= 1;
		rootlistAdd(x);
		x.marked = false;
	}
	
	
	private void cascadingCut(Node y) {
		Node z = y.parent;
		if(z != null) {
			if(!y.marked) y.marked = true;
			else {
				cut(y,z);
				cascadingCut(z);
			}
		}
	}
	
	
	
	private void rootlistCreateAndAdd(Node x) {
		x.right = x;
		x.left = x;
		min = x;
	}
	
	private void rootlistAdd(Node x) {
		x.right = min.right;
		x.left = min;
		min.right.left = x;
		min.right = x;
	}
	
	private void rootlistRemove(Node x) {
		x.right.left = x.left;
		x.left.right = x.right;
	}
	
	
	
	private class Node {
		Node parent, child, left, right;
		E entry;
		int degree;
		boolean marked;
		
		Node() {
			parent = child = left = right = null;
			entry = null;
			degree = 0;
			marked = false;
		}
		
		Node(E entry) {
			this();
			this.entry = entry;
		}
	}
}
