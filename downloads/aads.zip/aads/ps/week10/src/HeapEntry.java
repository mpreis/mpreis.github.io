public interface HeapEntry {
	public double getKey();
	public void setKey(double key);
}
