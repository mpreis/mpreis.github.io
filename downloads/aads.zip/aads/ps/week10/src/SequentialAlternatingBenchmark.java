import java.util.AbstractQueue;
import java.util.Map;

public class SequentialAlternatingBenchmark <E extends HeapEntry> extends Benchmark<E> {

	private int preload;
	
	public SequentialAlternatingBenchmark(String benchName, int nrOps, int preload , Map<Integer, E> entries) {
		super(benchName, nrOps, entries);
		this.preload = preload;
	}
	
	public SequentialAlternatingBenchmark(String benchName, int nrOps, int preload, Map<Integer, E> entries, AbstractQueue<E> queue) {
		this(benchName, nrOps, preload, entries);
		this.queue = queue;
	}
	
	@Override
	public long run() {
		long startTime = System.currentTimeMillis();
		
		for(int i = 0; i < preload; i++)
			queue.offer(entries.get(i));
		
		for(int i = preload; i < nrOps; i += 2){
			queue.offer(entries.get(i));
			queue.poll();
		}
		
		long execTime = System.currentTimeMillis() - startTime;
		return execTime;
	}

	@Override
	public String getSettings() {
		return "preload:" + preload;
	}

}
