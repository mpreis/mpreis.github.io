public class HeapEntryNode<E> implements HeapEntry, Comparable<HeapEntryNode<E>> {
	private double key;
	private E data;
		
	public HeapEntryNode() {
		data = null;
		key = 0.0;
	}
	
	public HeapEntryNode(double key) {
		this();
		this.key = key;
	}
	
	public HeapEntryNode(double key, E data) {
		this(key);
		this.data = data;
	}

	@Override
	public double getKey() {
		return key;
	}

	@Override
	public void setKey(double key) {
		this.key = key;			
	}
		
	public E getData() {
		return data;
	}
	
	public void setData(E data) {
		this.data = data;
	}


	@Override
	public int compareTo(HeapEntryNode<E> e) {
		return this.key < e.getKey()
				? -1 
				: this.key > e.getKey()
					? 1
					: 0;
	}
}
