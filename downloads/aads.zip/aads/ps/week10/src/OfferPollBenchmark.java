import java.util.AbstractQueue;
import java.util.Map;

public class OfferPollBenchmark<E extends HeapEntry> extends Benchmark<E> {

	private int nrOffers;
	
	public OfferPollBenchmark(String benchName, int nrOps, int nrOffers, Map<Integer, E> entries) {
		super(benchName, nrOps, entries);
		this.nrOffers = nrOffers;
	}
	
	public OfferPollBenchmark(String benchName, int nrOps, int nrOffers, Map<Integer, E> entries, AbstractQueue<E> queue) {
		super(benchName, nrOps, entries, queue);
		this.queue = queue;
	}

	@Override
	public long run() {
		long startTime = System.currentTimeMillis();
		
		for(int i = 0; i < nrOffers; i++)
			queue.offer(entries.get(i));
		
		for(int j = nrOffers; j < nrOps; j++)
			queue.poll();
		
		long execTime = System.currentTimeMillis() - startTime;
		return execTime;
	}

	@Override
	public String getSettings() {
		return "nrOffers:" + nrOffers + ", nrPolls:" + (nrOps-nrOffers);
	}

}
